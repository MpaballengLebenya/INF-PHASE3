<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pull-over Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
        body{
            background-color: whitesmoke;
            background-image: url("assets\\img\\pullza.jpg");
     
            background-size:115%; /* Make sure the image covers the entire area */
            background-position:cover; /* Center the background image */
            background-repeat: no-repeat;
            margin: top 0;
        }
    </style>
  </head>

  <body>
    <h1>Pull-over Information</h1>
    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school" onchange="updateColour()">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="school">
        <option value="size">20</option>
        <option value="size">22</option>
        <option value="size">24</option>
        <option value="size">26</option>
        <option value="size">28</option>
        <option value="size">30</option>
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="large">large</option>
        <option value="Extra large">Extra large</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Navy Blue">Navy</option>
        <option value=">Black and White">Black and White</option>
        <option value=">Black and powder blue">Black and powder blue</option>
        <option value="Black and red">Black and red</option>
        <option value="Black and Gold">Black and Gold</option>
        <option value="Red and White">Red and White</option>
        <option value="Green and Gold">Green and Gold</option>
        <option value="Navy and white">Navy and white</option>
        <option value="Navy and red">Navy and red</option>
        <option value="Maroon and baige">Maroon and baige</option>
        <option value="Green and white">Green and white</option>
        <option value="Maroon">Maroon</option>
        <option value="Powder blue and white">Powder blue and white</option>
        <option value="Blue">Blue</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div></div>
        <p class="price">R190.00</p>
      </div>
    </div>
    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="cart.php">Go to Cart</a>
    </div>

    <script>
      function addToCart() {
        const school = document.getElementById("school").value;
        const colour = document.getElementById("colour").value;
        const size = document.getElementById("size").value;

        const cartItem = { school, size, colour };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + school + ", " + size + ", " + colour);
      }

      function updateColour() {
        const school = document.getElementById("school").value;
        const colourSelect = document.getElementById("colour");

        if (school === "Masibambane High School") {
          colourSelect.value = "Navy and white";
        } else if (school === "Hector Peterson") {
          colourSelect.value = "Powder blue and white";
        } else if (school === "Wallacedene High School") {
          colourSelect.value = "Red and White";
        } else if (school === "Nqalweni JSS") {
          colourSelect.value = "Green and Gold";
        } else if (school === "Not in list") {
          colourSelect.value = "Blue";
        }
      }
      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value = "Green and Gold";
      };
    </script>
  </body>
</html>
