<?php
header('Content-Type: application/json');

$serverName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "khanya";

// Create connection
$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

// Check connection
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Connection failed: ' . mysqli_connect_error()]);
    exit; // Exit after sending an error response
}

// Get the input data from the request body
$input = file_get_contents("php://input");
error_log("Received input: " . $input); // Log the received input

// Check if input is empty
if (empty($input)) {
    echo json_encode(['success' => false, 'message' => 'No data received']); // Send JSON response
    exit; // Exit the script
}

// Decode the JSON input into a PHP array
$cartItems = json_decode($input, true);

// Calculate the total cost of the order
$totalCost = 0;
foreach ($cartItems as $item) {
    $totalCost += $item['price'] * $item['quantity'];
}

// You need to provide the customer ID (CUST_ID) directly in the JSON input
$custId = isset($cartItems[0]['cust_id']) ? $cartItems[0]['cust_id'] : 1; // Default to 1 if not set

// Prepare to insert the order
$orderQuery = "INSERT INTO orders (CUST_ID, ORDER_DATE, TOTAL_COST) VALUES (?, NOW(), ?)";
$stmt = $conn->prepare($orderQuery);
$stmt->bind_param("id", $custId, $totalCost);

if ($stmt->execute()) {
    $orderId = $stmt->insert_id; // Get the generated ORDER_ID

    // Insert each item into the order_items table
    $orderItemsQuery = "INSERT INTO order_items (ORDER_ID, PROD_ID, QUANTITY, ITEM_COST) VALUES (?, ?, ?, ?)";
    $orderItemStmt = $conn->prepare($orderItemsQuery);

    foreach ($cartItems as $item) {
        $orderItemStmt->bind_param("iiid", $orderId, $item['prod_id'], $item['quantity'], $item['price']);
        $orderItemStmt->execute();
    }

    echo json_encode(['success' => true, 'message' => 'Checkout successful.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to insert order.']);
}

// Clean up
$stmt->close();
$orderItemStmt->close();
$conn->close();
?>
