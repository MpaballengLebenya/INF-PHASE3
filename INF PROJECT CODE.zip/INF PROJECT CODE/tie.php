<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tie Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
    body{
            background-color: black;
            background-image: url("assets\\img\\Tie2.jpg");
     
            background-size: 70%; /* Make sure the image covers the entire area */
            background-position:right; /* Center the background image */
            background-repeat: no-repeat;
            margin: top 0;
        }
        </style>
  </head>
  <body>
    <h1>Tie Information</h1>

    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school" onchange="updateColour()">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Navy">Navy</option>
        <option value="Black and White">Black and White</option>
        <option value="Black and powder blue">Black and powder blue</option>
        <option value="Black and red">Black and red</option>
        <option value="Black and Gold">Black and Gold</option>
        <option value="Red and White">Red and White</option>
        <option value="Green and Gold">Green and Gold</option>
        <option value="Navy and white">Navy and white</option>
        <option value="Navy and red">Navy and red</option>
        <option value="Maroon and baige">Maroon and baige</option>
        <option value="Green and white">Green and white</option>
        <option value="Maroon">Maroon</option>
        <option value="Powder blue and white">Powder blue and white</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="One size">One size</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div>
        
          <p class="price">R80.00</p>
        </div>
      </div>
    </div>

    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="latest_cart.html">Go to Cart</a>
    </div>

    <script>
      function addToCart() {
        const school = document.getElementById("school").value;
        const colour = document.getElementById("colour").value;
        const size = document.getElementById("size").value;
        const price = 200; // Price of the item

        const cartItem = { school, size, colour, price, quantity: 1 };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + school + ", " + size + ", " + colour);
      }

      function updateColour() {
        const school = document.getElementById("school").value;
        const colourSelect = document.getElementById("colour");

        if (school === "Masibambane High School") {
          colourSelect.value = "Navy and white";
        } else if (school === "Hector Peterson") {
          colourSelect.value = "Powder blue and white";
        } else if (school === "Wallacedene High School") {
          colourSelect.value = "Red and White";
        } else if (school === "Nqalweni JSS") {
          colourSelect.value = "Green and Gold";
        } else if (school === "Not in list") {
          colourSelect.value = "Navy";
        }
      }

      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value = "Green and Gold";
      };
    </script>
  </body>
</html>
