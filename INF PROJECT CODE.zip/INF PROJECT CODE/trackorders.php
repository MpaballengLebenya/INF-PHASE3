<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        
    
            background-color: black;
            background-image: url("assets\\img\\calendar.jpg");
     
            background-size: 100%; /* Make sure the image covers the entire area */
            background-position:center; /* Center the background image */
            background-repeat: no-repeat;
            margin: top 0;
        
        }
        .tracking-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            overflow: hidden;
        }
        h1 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .steps {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }
        .step {
            display: flex;
            align-items: center;
            min-width: 100%;
            box-sizing: border-box;
            margin-bottom: 20px;
        }
        .step:last-child {
            margin-bottom: 0;
        }
        .step-indicator {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #ddd;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            margin-right: 10px;
        }
        .step-description {
            font-size: 16px;
        }
        .completed .step-indicator {
            background: #4CAF50;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="tracking-container">
        <h1>Order Tracking</h1>
        <div class="steps" id="steps">
            <div class="step completed" id="step1">
                <div class="step-indicator">1</div>
                <div class="step-description">Order Received</div>
            </div>
            <div class="step" id="step2">
                <div class="step-indicator">2</div>
                <div class="step-description">Processing</div>
            </div>
            <div class="step" id="step3">
                <div class="step-indicator">3</div>
                <div class="step-description">Shipped</div>
            </div>
            <div class="step" id="step4">
                <div class="step-indicator">4</div>
                <div class="step-description">Delivered</div>
            </div>
        </div>
    </div>

    <script>
        // Function to update the tracking steps
        function updateTrackingSteps() {
            const steps = document.getElementById('steps');
            const stepElements = steps.children;

            // Get the current step from local storage or initialize it
            let currentStep = localStorage.getItem('currentStep');
            if (!currentStep) {
                currentStep = 1; // Start from step 1 (0-based index)
            } else {
                currentStep = parseInt(currentStep);
            }

            // Mark previous steps as completed
            for (let i = 0; i <= currentStep; i++) {
                stepElements[i].classList.add('completed');
            }

            // Move the steps container to show the current step
            steps.style.transform = `translateX(-${currentStep * 100}%)`;

            // Update to the next step after 10 seconds
            if (currentStep < stepElements.length - 1) {
                currentStep++;
                localStorage.setItem('currentStep', currentStep);
                setTimeout(updateTrackingSteps, 10000); // 10 seconds in milliseconds
            }
        }

        // Initialize the current step to 0 and update it after the first 10 seconds
        localStorage.setItem('currentStep', 0);
        setTimeout(updateTrackingSteps, 10000); // Start the tracking update
    </script>
</body>
</html>
