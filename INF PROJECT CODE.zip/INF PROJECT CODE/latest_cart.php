<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Shopping Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: hsl(310, 33%, 93%);
            background-image: url("assets\\img\\trolley.jpg");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            color: #fff;
        }
        h1 {
            color: #fff;
        }
        .cart-item {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }
        .item-details {
            display: flex;
            flex-direction: column;
            margin-right: 10px;
        }
        .item-quantity {
            display: flex;
            align-items: center;
        }
        button {
            background-color: #fff;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
        button:hover {
            background-color: blueviolet;
            color: #fff;
        }
        .plus-button {
            background-color: #007bff;
            margin-left: 5px;
        }
        .plus-button:hover {
            background-color: #0056b3;
        }
        .minus-button {
            background-color: #dc3545;
            margin-right: 5px;
        }
        .minus-button:hover {
            background-color: #c82333;
        }
        .button {
            background-color: #fff;
            color: black;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }
        .checkout-button:hover {
            background-color: #e0a800;
        }
        .cart-container {
            margin-top: 20px;
        }
        .total-price {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="cart-container">
        <h2>Your Shopping Cart</h2>
        <div id="cart"></div>
        <div class="total-price">Total: R<span id="total">0.00</span></div>
    </div>

    <div>
        <button class="button" onclick="checkout()">Proceed to Checkout</button>
        <button class="button" onclick="backToMenu()">Go to menu</button>
        <button onclick="clearCart()" class="button" style="display: block;">Clear Cart</button>
    </div>

    <script>
        function clearCart() {
            localStorage.removeItem("cart");
            alert("Cart has been cleared!");
            loadCart();
        }

        function backToMenu() {
         
        }

        function loadCart() {
            const cart = JSON.parse(localStorage.getItem("cart")) || [];
            const cartContainer = document.getElementById("cart");
            cartContainer.innerHTML = "";
            let total = 0;

            cart.forEach((item, index) => {
                total += item.price * item.quantity;

                const cartItem = document.createElement("div");
                cartItem.className = "cart-item";

                cartItem.innerHTML = `
                    <div class="item-details">
                        <span><strong>School:</strong> ${item.school}</span>
                        <span><strong>Size:</strong> ${item.size}</span>
                        <span><strong>Colour:</strong> ${item.colour}</span>
                        <span><strong>Price:</strong> R${item.price}</span>
                    </div>
                    <div class="item-quantity">
                        <button class="minus-button" onclick="decrementQuantity(${index})">-</button>
                        <span>${item.quantity}</span>
                        <button class="plus-button" onclick="incrementQuantity(${index})">+</button>
                    </div>
                `;

                cartContainer.appendChild(cartItem);
            });

            document.getElementById("total").innerText = total.toFixed(2);
        }

        function incrementQuantity(index) {
            const cart = JSON.parse(localStorage.getItem("cart")) || [];
            cart[index].quantity += 1; // Increment quantity
            localStorage.setItem("cart", JSON.stringify(cart)); // Update localStorage
            loadCart(); // Reload cart to reflect changes
        }

        function decrementQuantity(index) {
            const cart = JSON.parse(localStorage.getItem("cart")) || [];
            if (cart[index].quantity > 1) {
                cart[index].quantity -= 1; // Decrement quantity
                localStorage.setItem("cart", JSON.stringify(cart)); // Update localStorage
            } else {
                // If quantity is 1, remove item from cart
                cart.splice(index, 1);
                localStorage.setItem("cart", JSON.stringify(cart));
            }
            loadCart(); // Reload cart to reflect changes
        }

        function checkout() {
            const cart = JSON.parse(localStorage.getItem("cart")) || [];

            if (cart.length === 0) {
                alert("Your cart is empty!");
                return;
            }

            console.log("Cart data being sent:", cart);

            // Send cart data to the server
            fetch("checkout.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(cart),
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if (data.success) {
                    localStorage.removeItem("cart");
                    alert(data.message);
                    window.location.href = "pay.php"; // Redirect to payment page
                } else {
                    console.log("Error: Cart data processing failed.");
                    alert("Error: " + data.message);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("There was an error processing your checkout.");
            });
        }
    
        function backToMenu() {
            window.location.href = 'index.php'; // Redirect to index.php
        }
        document.addEventListener("DOMContentLoaded", loadCart);
    </script>
</body>
</html>
