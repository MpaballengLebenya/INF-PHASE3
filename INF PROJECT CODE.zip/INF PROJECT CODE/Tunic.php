<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tunic Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
    body{
            background-color: black;
            background-image: url("assets\\img\\tunic (2).jpg");
     
            background-size: 100%; /* Make sure the image covers the entire area */
            background-position:center; /* Center the background image */
            background-repeat: no-repeat;
            margin: top 0;
        }
        </style>
  </head>
  <body>
    <h1>Tunic Information</h1>

    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school" onchange="updateColours()">
        <option value="Not in list">Not in list</option>
        <option value="ET Thabane primary school">
          ET Thabane primary school
        </option>
        <option value="Wonderland JSS">Wonderland JSS</option>
        <option value="Mida primary school">Mida primary school</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Victory Christian School">
          Victory Christian School
        </option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="size">3-4</option>
        <option value="size">5-6</option>
        <option value="size">7-8</option>
        <option value="size">9-10</option>
        <option value="size">11-12</option>
        <option value="size">13-14</option>
        <option value="size">15-16</option>
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="large">large</option>
        <option value="Extra large">Extra large</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select type of tunic:</h2>
      <select id="type_tunic" onchange="updatePriceAndImage()">
        <option value="plitted">Plitted</option>
        <option value="6 panel">6 Panel</option>
        <option value="checked">checked</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Navy">Navy</option>
        <option value="Checked navy">Checked navy</option>
        <option value="Red">Red</option>
        <option value="Green">Green</option>
        <option value="Powder blue">Powder blue</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div>
          <p class="price" id="price">R300.00</p>
        </div>
      </div>

      <div>
        <a href="uniform.php">Back</a>
      </div>
      <div id="cart">
        <a href="latest_cart.php">Go to Cart</a>
      </div>
    </div>

    <script>
      function updatePriceAndImage() {
        const typeTunic = document.getElementById("type_tunic").value;
        let price;
        let imageSrc;

        if (typeTunic === "plitted") {
          price = 250;

          imageSrc = "tunic.jpg";
        } else if (typeTunic === "6 panel") {
          price = 200;
          imageSrc = "checked tunic.jpg";
        } else if (typeTunic === "checked") {
          price = 200;
          imageSrc = "6 panel tunic.webp";
        }

        document.getElementById("price").innerText = "R" + price + ".00";
        document.getElementById("tunic-image").src = imageSrc;
      }
      function updateColours() {
        const school = document.getElementById("school").value;
        const colourSelect = document.getElementById("colour");
        if (school === "Wonderland JSS") {
          colourSelect.value = "Navy";
        } else if (school === "ET Thabane primary school") {
          colourSelect.value = "Powder blue";
        } else if (school === "Nqalweni JSS") {
          colourSelect.value = "Green";
        } else if (school === "Victory Christian School") {
          colourSelect.value = "Red";
        } else if (school === "Mida primary school") {
          colourSelect.value = "Checked navy";
        } else if (school === "Not in list") {
          colourSelect.value = "White";
        }
      }
      function addToCart() {
        const school = document.getElementById("school").value;
        const size = document.getElementById("size").value;
        const typeTunic = document.getElementById("type_tunic").value;
        const colour = document.getElementById("colour").value;
        const price = typeTunic === "plitted" ? 250 : 230;

        const cartItem = {
          school,
          size,
          typeTunic,
          colour,
          price,
          quantity: 1,
        };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert(
          "Item added to cart: " +
            school +
            ", " +
            size +
            ", " +
            typeTunic +
            ", " +
            colour +
            ", R" +
            price
        );
      }
    </script>
  </body>
</html>
