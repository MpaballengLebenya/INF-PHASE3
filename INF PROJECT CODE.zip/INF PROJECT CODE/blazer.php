<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Blazer Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
        body{
            background-color: whitesmoke;
            background-image: url("assets\\img\\belungu.jpg");
     
            background-size: 110%; /* Make sure the image covers the entire area */
            background-position:cover; /* Center the background image */
            background-repeat: no-repeat;
            margin: top 0;
        }
    </style>
  </head>
  <body>
    <h1>Blazer Information</h1>
    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school" onchange="updateColour()">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="5-6">5-6</option>
        <option value="7-8">7-8</option>
        <option value="9-10">9-10</option>
        <option value="11-12">11-12</option>
        <option value="13-14">13-14</option>
        <option value="15-16">15-16</option>
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="large">Large</option>
        <option value="Extra large">Extra large</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Navy blue">Navy</option>
        <option value="Black">Black</option>
        <option value="Grey">Grey</option>
        <option value="Blue">Blue</option>
        <option value="Black and powder blue">Black and powder blue</option>
        <option value="Red and White">Red and White</option>
        <option value="Green and Gold">Green and Gold</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div></div>
        <p class="price">R600.00</p>
      </div>
    </div>
    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="latest_cart.php">Go to Cart</a>
    </div>

    <script>
      function addToCart() {
        const school = document.getElementById("school").value;
        const colour = document.getElementById("colour").value;
        const size = document.getElementById("size").value;

        const cartItem = { school, size, colour };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + school + ", " + size + ", " + colour);
      }

      function updateColour() {
        const school = document.getElementById("school").value;
        const colourSelect = document.getElementById("colour");

        if (school === "Masibambane High School") {
          colourSelect.value = "Navy blue";
        } else if (school === "Hector Peterson") {
          colourSelect.value = "Black";
        } else if (school === "Wallacedene High School") {
          colourSelect.value = "Red and White";
        } else if (school === "Nqalweni JSS") {
          colourSelect.value = "Green and Gold";
        } else if (school === "Not in list") {
          colourSelect.value = "Blue";
        }
      }
      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value = "Grey";
      };
    </script>
  </body>
</html>
