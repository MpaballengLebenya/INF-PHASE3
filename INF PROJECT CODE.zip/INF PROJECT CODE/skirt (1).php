<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Skirt Information</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        margin: 20px;
        line-height: 1.6;
      }
      h1 {
        color: #4caf50;
      }
      .info-section {
        margin-top: 20px;
      }
      .info-section h2 {
        font-size: 20px;
        color: #333;
        margin-bottom: 10px;
      }
      .info-section select,
      .info-section button {
        font-size: 16px;
        padding: 5px;
        margin-top: 10px;
        margin-bottom: 20px;
      }
      a {
        text-decoration: none;
        color: #4caf50;
        font-weight: bold;
      }
    </style>
  </head>
  <body>
    <h1>Skirt Information</h1>

    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="school">
        <option value="size">24</option>
        <option value="size">26</option>
        <option value="size">28</option>
        <option value="size">30</option>
        <option value="size">32</option>
        <option value="size">34</option>
        <option value="size">36</option>
        <option value="size">38</option>
        <option value="size">40</option>
        <option value="size">42</option>
        <option value="size">44</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Navy Blue">Navy</option>
        <option value="Black">Black</option>
        <option value="Grey">Grey</option>
        <option value="Black">Blue</option>
      </select>
    </div>

    <div class="info-section">
      <button type="button" onclick="submitSelection()">Submit</button>
    </div>

    <a href="uniform.html">Back to Menu</a>

    <script>
      function submitSelection() {
        const school = document.getElementById("school").value;
        const colour = document.getElementById("colour").value;
        const size = document.getElementById("size").value;
        alert(
          "You have selected:\nSchool: ${school}\nColour: ${colour}\nSize: ${Size}"
        );
      }
    </script>
  </body>
</html>
