<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tracksuit Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
    body{
            background-color: black;
            background-image: url("assets\\img\\tracksuit.jpg");
     
            background-size: 45%; /* Make sure the image covers the entire area */
            background-position:center; /* Center the background image */
            background-repeat: repeat;
            margin: top 0;
        }
        </style>
  </head>
  <body>
    <h1>Tracksuit Information</h1>

    <div class="info-section">
      <h2>Select School(optional):</h2>
      <select id="school">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Victory Christian School">
          Victory Christian School
        </option>
        <option value="Idutywa School of Excellence">
          Idutywa School of Excellence
        </option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="school">
        <option value="Small">3-4</option>
        <option value="size">5-6</option>
        <option value="size">7-8</option>
        <option value="size">9-10</option>
        <option value="size">11-12</option>
        <option value="size">13-14</option>
        <option value="size">15-16</option>

        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="large">large</option>
        <option value="Extra large">Extra large</option>
      </select>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div></div>
        <p class="price">R500.00</p>
      </div>
    </div>
    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="latest_cart.php">Go to Cart</a>
    </div>

    <script>
      function addToCart() {
        const school = document.getElementById("school").value;
        const colour = document.getElementById("colour").value;
        const size = document.getElementById("size").value;

        const cartItem = { school, size, colour };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + school + ", " + size + ", " + colour);
      }
    </script>
  </body>
</html>
