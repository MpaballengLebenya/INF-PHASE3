const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());

// MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'khanya'
});

connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Endpoint to get customer details
app.get('/api/customer/:id', (req, res) => {
    const customerId = req.params.id;
    const query = 'SELECT * FROM CUSTOMERS WHERE CUSTOMER_ID = ?';
    connection.query(query, [customerId], (err, results) => {
        if (err) throw err;
        res.json(results[0]);
    });
});

// Endpoint to handle checkout
app.post('/api/checkout', (req, res) => {
    const cart = req.body.cart;

    // Insert order
    const orderQuery = 'INSERT INTO ORDERS (CUSTOMER_ID, ORDER_DATE, TOTAL_COST) VALUES (?, ?, ?)';
    const orderValues = [1, new Date(), cart.reduce((total, item) => total + (item.price * item.quantity), 0)]; // Assuming CUSTOMER_ID is 1 for example

    connection.query(orderQuery, orderValues, (err, result) => {
        if (err) {
            res.status(500).send(err);
            return;
        }

        const orderId = result.insertId;

        // Insert order items
        const orderItemsQuery = 'INSERT INTO ORDER_ITEMS (ORDER_ID, PROD_ID, QUANTITY, ITEM_COST) VALUES ?';
        const orderItemsValues = cart.map(item => [orderId, item.prodId, item.quantity, item.price]);

        connection.query(orderItemsQuery, [orderItemsValues], (err) => {
            if (err) {
                res.status(500).send(err);
                return;
            }

            res.status(200).send({ message: 'Checkout successful', orderId: orderId });
        });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
