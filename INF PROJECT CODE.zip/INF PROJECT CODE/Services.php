<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Services.css">
</head>
<body>
    
<h1> Services offered at Khanya's store</h1>

<div class="Container-services">
    <ul id="specials-list">
    <li id="Season-specials">Fittings<img src="assets\img\shirts.jpg" alt=" Fittings"/> </li>
    <li id="Season-specials"> Customized <img src="assets\img\blaazer.jpg" alt="Customized Uniforms"/></li>
    <li id="Season-specials">Quality Assurance<img src="assets\img\OIP.jpg" alt =" Quality Assurance"/></li>
    <li id="Season-specials">Bulk Orders<img src="assets\img\mnqwazi.jpg" alt =" Bulk Order"/></li>
   </ul>
   
</div>

</body>
</html>