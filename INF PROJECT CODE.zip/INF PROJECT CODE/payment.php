<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Registration Page</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
        background-color: #f2f2f2;
      }

      .container {
        width: 700px;
        background: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      }

      .form-container {
        position: relative;
        width: 100%;
      }

      .form-btn {
        display: flex;
        justify-content: space-around;
        cursor: pointer;
        margin-bottom: 20px;
        position: relative;
      }

      .form-btn span {
        font-size: 18px;
        color: #555;
      }
      #indicator {
        width: 45%;
        border: 2px solid #c72185;
        transition: 0.5s;
        position: absolute;
        left: 8%;
        top: 60%;
      }

      form {
        display: none;
      }

      form.active {
        display: block;
      }

      input {
        width: 95%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
      }

      .btn {
        width: 100%;
        padding: 10px;
        background-color: #c72185;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }

      .btn:hover {
        background-color: #4b042f;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="form-container">
        <div class="form-btn">
          <span onclick="showLogin()">Login</span>
          <span onclick="showRegister()">Register</span>
          <hr id="indicator" />
        </div>
<!-- Login Form -->
<form id="loginForm" action="index.php" method="post">
  <input type="email" name="email" placeholder="Enter your email"  />
  <input type="password" name="password" placeholder="Enter your password" />
  <button type="submit" name="submit-btn" class="btn">
    Login
  </button>
  <?php
    // Check if there is an error in the URL
    if (isset($_GET['error'])) {
        if ($_GET['error'] == "nouser") {
            echo "<p style='color:red;'>No user found with that username. Please try again or create a new account.</p>";
        } else if ($_GET['error'] == "wrongpassword") {
            echo "<p style='color:red;'>Incorrect password. Please try again.</p>";
        } else if ($_GET['error'] == "stmtfailed") {
            echo "<p style='color:red;'>Something went wrong. Please try again later.</p>";
        }
    }
    ?>
</form>


        <!-- Register Form -->
        <form
          id="registerForm"
          action="../includes/signup.inc.php"
          method="post"
        >
          <input
            type="text"
            name="fullname"
            placeholder="Enter your full name"
            required
          />
          <input
            type="tel"
            name="phone-number"
            placeholder="Enter your Phone number"
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Enter your email address"
            required
          />
          <input
            type="text"
            name="h-address"
            placeholder="Enter your home address"
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Create a password"
            required
          />
          <button
            type="submit"
            name="submit"
            class="btn"
            onclick="alert('Registered successfully, happy shopping!')"
          >
            Register
          </button>
        </form>
      </div>
    </div>
    <!-- Javascript -->
    <script>
      const loginForm = document.getElementById("loginForm");
      const registerForm = document.getElementById("registerForm");
      const indicator = document.getElementById("indicator");

      function showLogin() {
        loginForm.classList.add("active");
        registerForm.classList.remove("active");
        indicator.style.transform = "translateX(0)";
      }

      function showRegister() {
        loginForm.classList.remove("active");
        registerForm.classList.add("active");
        indicator.style.transform = "translateX(100%)";
      }

      showLogin();
    </script>
  </body>
</html>