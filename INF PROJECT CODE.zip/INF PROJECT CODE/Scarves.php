<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Scarf Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
        body{
            background-color: whitesmoke;
            background-image: url("assets\\img\\skafs.jpg");
     
            background-size:100%; /* Make sure the image covers the entire area */
            background-position:cover; /* Center the background image */
            background-repeat: no-repeat;
            margin: top 0;
        }
    </style>
  </head>
  <body>
    <h1>Scarf Information</h1>

    <div class="info-section">
      <h2>Select School (optional):</h2>
      <select id="school" onchange="updateColour()">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Navy">Navy</option>
        <option value="Black">Black</option>
        <option value="Green and Gold">Green and Gold</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
      
      </div>
    </div>

    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="cart.html">Go to Cart</a>
    </div>

    <script>
      function addToCart() {
        const school = document.getElementById("school").value;
        const colour = document.getElementById("colour").value;

        const cartItem = { school, colour };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + school + ", " + colour);
      }

      function updateColour() {
        const school = document.getElementById("school").value;
        const colourSelect = document.getElementById("colour");

        if (school === "Masibambane High School") {
          colourSelect.value = "Navy";
        } else if (school === "Wallacedene High School") {
          colourSelect.value = "Black";
        } else if (school === "Hector Peterson") {
          colourSelect.value = "Navy";
        } else if (school === "Nqalweni JSS") {
          colourSelect.value = "Green and Gold";
        } else {
          colourSelect.value = "Navy"; // Default colour for "Not in list"
        }
      }

      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value = "Green and Gold";
      };
    </script>
  </body>
</html>
