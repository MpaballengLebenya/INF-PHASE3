<?php

// Database connection
require_once '../includes/khanya.php';

if (isset($_POST['submit'])) {
    // Retrieve data from form
    $Fullname = htmlspecialchars($_POST['fullname']);
    $Mob_phone = htmlspecialchars($_POST['phone-number']);
    $Email = htmlspecialchars($_POST['email']);
    $Address = htmlspecialchars($_POST['h-address']);
    $Password = htmlspecialchars($_POST['password']);

    // Validate input (e.g., check for empty fields, email validation)
    if (empty($Fullname) || empty($Mob_phone) || empty($Email) || empty($Address) || empty($Password)) {
        header("Location: ../payment.php?error=emptyfields");
        exit();
    } elseif (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../payment.php?error=invalidemail");
        exit();
    }

    // Check if the user already exists
    $sql = "SELECT * FROM customers WHERE FIRSTNAME = ? OR EMAIL_ADDRESS = ?";
    $stmt = mysqli_stmt_init($conn);
    
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../payment.php?error=sqlerror");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ss", $Fullname, $Email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {
        header("Location: ../signup.php?error=useroremailtaken");
        exit();
    }

    // Insert new user  
    $sql = "INSERT INTO customers (FIRSTNAME, MOB_PHONE , EMAIL_ADDRESS, Home_ADDRESS, Password) VALUES (?, ?, ?, ?, ?)";
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../signup.php?error=sqlerror");
        exit();
    }
    
    // Hash the password
    $hashedPwd = password_hash($Password, PASSWORD_DEFAULT);

    mysqli_stmt_bind_param($stmt, "sssss", $Fullname, $Mob_phone, $Email, $Address, $hashedPwd);
    mysqli_stmt_execute($stmt);
 
    // Success
    header("Location: ../payment.php?signup=success");
    exit();
    
    // Close the statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    header("Location: ../signup.php");
    exit();
}
?>
