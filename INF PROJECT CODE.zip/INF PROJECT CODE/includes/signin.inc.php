<?php

// Database connection
require_once '../includes/khanya.php';

if (isset($_POST['submit-btn'])) {
    $Email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);

    // Check for empty input
    if (empty($Email) || empty($password)) {
        header("Location: ../payment.php?error=emptyfields");
        exit();
    }

    // SQL to fetch user data
    $sql = "SELECT * FROM customers WHERE EMAIL_ADDRESS = ?";
    $stmt = mysqli_stmt_init($conn);

    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../payment.php?error=stmtfailed");
        exit();
    }

    // Bind parameters and execute the query
    mysqli_stmt_bind_param($stmt, "s", $Email);
    mysqli_stmt_execute($stmt);
    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {
        // Verify password
        $pwdCheck = password_verify($password, $row['Password']);
        
        if ($pwdCheck === false) {
            header("Location: ../payment.php?error=wrongpassword");
            exit();
        } else if ($pwdCheck === true) {
            // Start session and set session variables
            session_start();
            $_SESSION["CUST_ID"] = $row["CUST_ID"];
            $_SESSION["Email"] = $row["EMAIL_ADDRESS"];

            // Redirect to home page or dashboard
            header("Location: ../index.php?login=success");
            exit();
        }
    } else {
        // No user found with that username
        header("Location: ../payment.php?error=nouser");
        exit();
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {

    header("Location: ../payment.php");
    exit();
}
?>