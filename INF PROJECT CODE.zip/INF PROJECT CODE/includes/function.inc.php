<?php 
// Create User function
function createUser($conn, $fullname, $email, $password) {
    // ? = value
    $sql = "INSERT INTO users(username, password, email) VALUES(?, ?, ?)";
    // Responsible for connecting with database
    $stmt = mysqli_stmt_init($conn);

    if (!mysqli_stmt_prepare($stmt, $sql)) {
        return false;
    }

    // Hash password
    $hashedPwd = password_hash($password, PASSWORD_DEFAULT);
     
    // s = string 
    mysqli_stmt_bind_param($stmt, "sss", $fullname, $email, $hashedPwd);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return true;
}

// Login user

function loginUser($conn, $username, $password) {
    $sql = "SELECT * FROM users WHERE username = ? And password = ?";
    $stmt = mysqli_stmt_init($conn);

    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header('location: ../signin.php?error=stmtfailed');
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ss", $username,$password);
    mysqli_stmt_execute($stmt);
    $resultData = mysqli_stmt_get_result($stmt);
    

 

    if ($row = mysqli_fetch_assoc($resultData)) {
        $pwdCheck = password_verify($password, $row['password']);
        if ($pwdCheck === false) {
            header('location: ../signin.php?error=wrongpassword');
            exit();
        }
        // } else if ($pwdCheck === true) {
        //     session_start();
        //     $_SESSION["userid"] = $row["user_id"];
        //     $_SESSION["username"] = $row["username"];
        //     header('location: ../index.php');
        //     exit();
        // }
    } else {
        // No user found
        echo "<p>No user found with that username.</p>"; // Optional for debugging
        header('location: ../signin.php?error=nouser');
        exit();
    }
    

    mysqli_stmt_close($stmt);
}

?>
